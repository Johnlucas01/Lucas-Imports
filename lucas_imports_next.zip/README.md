# Lucas Imports — Next.js + Tailwind scaffold

Este é um scaffold inicial gerado automaticamente para **Lucas Imports**.
Cores: azul-marinho (#0b3d91) + branco.

## Como usar

1. Instale dependências:
```bash
npm install
```

2. Para rodar em modo desenvolvimento:
```bash
npm run dev
```

3. Para build:
```bash
npm run build
npm start
```

> Observação: você precisa ter Node.js (v18+) instalado. Depois de subir no Vercel, a maioria das configurações de Tailwind e Next funciona automaticamente. Se quiser, posso te orientar no deploy passo-a-passo.

